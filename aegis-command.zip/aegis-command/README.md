# Aegis Command

A local hackathon prototype for incident coordination during a synthetic ransomware exercise.

## Run locally

Install Node.js 20 or newer, unzip the project, and open a terminal in this folder.

```sh
npm start
```

Open http://127.0.0.1:8080. No package installation, internet access, or API credentials are required. Use two browser tabs and select Maya Chen in one and Alex Rivera in the other. Updates appear in both tabs through short-interval polling.

The server binds to loopback by default and writes exercise changes to `aegis-state.json` in the current directory. For a fresh exercise, stop the server and rename that file, or set `AEGIS_STATE` to a new path before starting. Run one server per state file.

## Walk through the incident

1. Open **Scope** and select **Edit assessment** for Customer records.
2. Set **Availability** to **Accessible** and **Recovery** to **Validated**. Enter a restore rationale and save. **Suspected exposure** and **Suspected** exfiltration stay visible.
3. Check **Timeline** for the new revision and expand the previous assessment. To demonstrate a conflict, open the same assessment in both tabs before saving, then attempt to save both.
4. In **Communications**, acknowledge the critical instruction as Alex. Post a new update as Maya and see it in Alex’s tab.
5. In **Review**, prepare, review, and publish the checkpoint as Maya. Acknowledge it as Alex. Download the JSON exercise record if needed.

## Prototype scope

The project uses browser JavaScript and a dependency-free Node.js server with atomic JSON state replacement. The exercise has one seeded incident and two selectable personas. Scope assessments have version checks and prior-state history. Server-accepted writes are serialized, and message retries reuse the original submission ID. The health indicator reports local sync. **Use synthetic data only.**

The production TRD calls for Go, React and TypeScript, PostgreSQL, authorized WebSocket subscriptions, independent identity and device admission, a physically separate network, evidence quarantine, approved exports, external audit anchoring, and tested recovery. Those are outside this prototype. The people selector demonstrates responder actions, evidence entries are references, and export downloads the synthetic record. The original PRD and TRD are included under `requirements/`.

Run `npm run check` for syntax checks.
