const views = ['Overview', 'Timeline', 'Scope', 'Tasks', 'Communications', 'Evidence', 'Review'];
const statuses = {
  availability: ['Unknown', 'Accessible', 'Degraded', 'Locked', 'Unavailable'],
  exposure: ['Unknown', 'Suspected exposure', 'Confirmed exposure', 'No evidence found'],
  exfiltration: ['Unknown', 'Suspected', 'Confirmed', 'Not observed'],
  integrity: ['Unknown', 'Suspected alteration', 'Confirmed alteration', 'Verified against baseline'],
  containment: ['Unknown', 'Pending', 'In progress', 'Contained'],
  recovery: ['Pending', 'In progress', 'Validated'],
};
const fields = Object.keys(statuses);
const byId = id => document.getElementById(id);
const content = byId('content');
const editor = byId('editor');
let state;
let page = 'Overview';
let myTasks = false;
let focus = false;
let lastSync;
let online = false;
let stateStamp = '';
let draft;
let fallbackID = 0;
const tabID = Math.random().toString(36).slice(2);

const escape = value => String(value ?? '').replace(/[&<>"']/g, character => (
  { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]
));
const actor = () => byId('actor').value;
const formatTime = value => new Intl.DateTimeFormat('en-GB', {
  dateStyle: 'medium', timeStyle: 'medium', timeZone: 'UTC',
}).format(new Date(value)) + ' UTC';
const stamp = value => '<time datetime="' + escape(value) + '">' + formatTime(value) + '</time>';
const chip = (value, theme = '') => '<span class="chip ' + theme + '">' + escape(value) + '</span>';
const panel = (kicker, title, body, extra = '') => '<section class="panel ' + extra + '"><p class="kicker">' + kicker + '</p><h2>' + title + '</h2>' + body + '</section>';
const action = (label, key, index = '', theme = '') => '<button type="button" class="button ' + theme + '" data-action="' + key + '" data-index="' + index + '">' + label + '</button>';
const notice = text => { byId('notice').textContent = text; };
const statusChip = value => chip(value, ({
  Locked: 'red', Unavailable: 'red', 'Confirmed exposure': 'red', Confirmed: 'red',
  'Suspected exposure': 'amber', Suspected: 'amber', Degraded: 'amber',
  Accessible: 'green', Validated: 'green', Contained: 'green', 'In progress': 'blue',
})[value]);

function tasks(short = false) {
  const matching = state.tasks.map((task, index) => [task, index]).filter(([task]) =>
    (!short || !task.done) && (!myTasks || task.owner === actor()));
  return '<ul class="list">' + (matching.map(([task, index]) => `
    <li class="entry"><div><h3>${escape(task.title)}</h3><p class="small muted">${escape(task.owner)} · ${escape(task.due)}</p></div>
    ${task.done ? chip('Complete', 'green') : short ? chip('Open') : action('Complete', 'task', index)}</li>`).join('') || '<li>No matching tasks.</li>') + '</ul>';
}

function timeline(limit) {
  return '<ul class="list">' + state.events.slice(0, limit).map(event => `
    <li><div class="entry"><h3>${escape(event.title)}</h3>${stamp(event.time)}</div>
    <p class="small">${escape(event.detail)}</p><p class="small muted">${escape(event.actor)}</p>
    ${event.prior ? `<details class="small"><summary>Previous assessment · revision ${event.prior.revision}</summary>
      <p>${fields.map(key => escape(key + ' · ' + event.prior[key])).join(' / ')}</p><p>${escape(event.prior.reason)}</p></details>` : ''}</li>`).join('') + '</ul>';
}

function communications() {
  return panel('INCIDENT CHANNEL', 'General', `<ul class="list messages" id="messages" tabindex="0" aria-label="General channel messages">
    ${state.messages.map((message, index) => `<li><div class="entry"><h3>${escape(message.author)}</h3>${stamp(message.time)}</div>
    ${message.critical ? chip('Critical instruction', 'amber') : ''}<p class="preserve">${escape(message.body)}</p>
    ${message.critical ? `<p class="small muted">${message.acks.length ? 'Acknowledged by ' + escape(message.acks.join(', ')) : 'Awaiting acknowledgment'}</p>
    ${message.acks.includes(actor()) ? '' : action('Acknowledge', 'ack', index)}` : ''}</li>`).join('')}
    </ul><form id="compose" class="form"><label for="message">Incident update</label>
    <textarea id="message" name="body" placeholder="Share a confirmed update or request…" maxlength="12000" required></textarea>
    <label class="check"><input type="checkbox" name="critical"> Require explicit acknowledgment</label>
    <div class="actions"><button class="button primary" type="submit">Send update</button><span id="send-status" class="small muted" role="status"></span></div></form>`);
}

function overview() {
  const counts = [
    [state.scope.length, 'Datasets and assets'],
    [state.scope.filter(row => row.exposure === 'Suspected exposure').length, 'Suspected exposure'],
    [state.scope.filter(row => row.exposure === 'Confirmed exposure').length, 'Confirmed exposure'],
  ];
  const customer = state.scope[0];
  return `<div class="grid"><div class="stack">
    ${panel('01 / SITUATION', 'Current assessment', `<p class="lead">Ransomware was identified on the customer records volume. The dataset is <strong>${escape(customer.availability.toLowerCase())}</strong>. Exfiltration assessment: <strong>${escape(customer.exfiltration.toLowerCase())}</strong>.</p>
    <div class="metrics">${counts.map(([count, label]) => `<div class="metric"><strong>${count}</strong><span>${label}</span></div>`).join('')}</div>`)}
    ${panel('02 / CONFIDENCE LEDGER', 'Facts & open questions', `<ul class="list ledger"><li>${chip('Confirmed fact', 'green')}<h3>Encryption observed on the customer records volume</h3><p class="small muted">Recorded at declaration · IR-2026-017</p></li>
    <li>${chip('Working hypothesis', 'amber')}<h3>Outbound transfer contained customer records</h3><p class="small muted">Maya Chen · Review at 16:00 UTC · EV-014</p></li></ul>`)}
    ${focus ? '' : panel('03 / INCIDENT RECORD', 'Latest activity', timeline(4))}
  </div><div class="stack">
    ${panel('COMMAND PRIORITIES', 'Next actions', tasks(true) + '<div class="actions">' + action('Open tasks', 'tasks-view') + '</div>')}
    ${panel('DECISION QUEUE', 'Pending decision', '<h3>Approve phased return to service</h3><p class="small muted">Maya Chen · Review restore validation and residual exposure at 16:00 UTC.</p>')}
    ${focus ? communications() : panel('SHIFT HANDOVER', 'Next team briefing', '<p class="small muted">Review confirmed changes, outstanding work, and open assessments before publishing.</p><div class="actions">' + action('Open shift review', 'review-view') + '</div>')}
  </div></div>`;
}

function scope() {
  return panel('IMPACT ASSESSMENT', 'Scope register', `
    <p class="small muted">Impact dimensions are assessed independently. Unknown volumes remain explicit. Dataset counts are shown individually.</p>
    <div class="table-wrap" role="region" tabindex="0" aria-label="Scope register table"><table>
    <thead><tr><th scope="col">Asset / dataset</th><th scope="col">Availability</th><th scope="col">Confidentiality</th><th scope="col">Exfiltration</th><th scope="col">Integrity</th><th scope="col">Containment</th><th scope="col">Recovery</th><th scope="col">Assessment</th></tr></thead><tbody>
    ${state.scope.map((row, index) => `<tr><th scope="row">${escape(row.name)}<p class="small muted">${escape(row.owner)}<br>${escape(row.volume)}</p></th>
      <td>${statusChip(row.availability)}</td><td>${statusChip(row.exposure)}</td><td>${statusChip(row.exfiltration)}</td><td>${statusChip(row.integrity)}</td><td>${statusChip(row.containment)}</td><td>${statusChip(row.recovery)}</td>
      <td><p class="small muted">${escape(row.evidence)} · Rev ${row.revision}</p>${action('Edit assessment', 'scope', index)}</td></tr>`).join('')}
    </tbody></table></div>`);
}

function review() {
  const checkpoint = state.checkpoint;
  return panel('SHIFT HANDOVER', 'Review & publish', `<p>Prepare a handover from the current scope, open tasks, and incident timeline.</p>
    <div class="actions">${action('Prepare checkpoint', 'checkpoint', '', 'primary')}${action('Download exercise record', 'export')}</div>
    ${checkpoint ? `<div class="checkpoint"><h3>Published checkpoint</h3><p class="small muted">${escape(checkpoint.author)} · ${stamp(checkpoint.time)}</p>
    <p class="preserve">${escape(checkpoint.body)}</p><p class="small muted">${checkpoint.acks.length ? 'Acknowledged by ' + escape(checkpoint.acks.join(', ')) : 'Awaiting incoming acknowledgment'}</p>
    ${checkpoint.author !== actor() && !checkpoint.acks.includes(actor()) ? action('Acknowledge handover', 'handover') : ''}</div>` : ''}`);
}

const renderPage = {
  Overview: overview,
  Timeline: () => panel('INCIDENT RECORD', 'Timeline', timeline()),
  Scope: scope,
  Tasks: () => panel('ACTION REGISTER', myTasks ? 'My tasks' : 'Incident tasks', tasks()),
  Communications: communications,
  Evidence: () => panel('REFERENCE MANIFEST', 'Evidence register', '<p class="small muted">Synthetic references for this exercise.</p><ul class="list">' +
    state.evidence.map(entry => '<li>' + escape(entry) + '</li>').join('') + '</ul>'),
  Review: review,
  People: () => panel('EXERCISE ROSTER', 'People', '<ul class="list"><li><h3>Maya Chen</h3><p>Incident commander</p></li><li><h3>Alex Rivera</h3><p>Responder</p></li></ul><p class="small muted">Use the responder selector to demonstrate both sides of the handover.</p>'),
  'System health': () => panel('LOCAL SERVICE', 'System health', '<p id="health-state"></p><p class="small muted">The exercise uses a local server and disk-backed state. Only synthetic data belongs in this environment.</p>'),
};

function render() {
  if (!state) return;
  const active = document.activeElement;
  const actionKey = active?.dataset.action;
  const actionIndex = active?.dataset.index;
  const composer = byId('compose');
  const oldScroll = byId('messages')?.scrollTop;
  const editingMessage = composer?.contains(active);
  const activeName = active?.name;
  const draftBody = composer?.elements.body.value;
  const selection = activeName === 'body' ? [active.selectionStart, active.selectionEnd] : null;
  const critical = composer?.elements.critical.checked;
  const sendStatus = byId('send-status')?.textContent;
  content.innerHTML = renderPage[page]();
  const nextComposer = byId('compose');
  if (nextComposer && composer) {
    nextComposer.elements.body.value = draftBody;
    nextComposer.elements.critical.checked = critical;
    byId('messages').scrollTop = oldScroll;
    byId('send-status').textContent = sendStatus;
    if (editingMessage && activeName) {
      nextComposer.elements[activeName].focus();
      if (selection) nextComposer.elements.body.setSelectionRange(...selection);
    }
  }
  if (actionKey && content.contains(active) === false && !editor.open) {
    const matching = [...content.querySelectorAll('[data-action]')].find(button =>
      button.dataset.action === actionKey && button.dataset.index === actionIndex);
    matching?.focus();
  }
  updateConnection();
}

function updateConnection() {
  const connection = byId('connection');
  const label = online ? 'Live on local server' : lastSync ? 'Disconnected' : 'Connecting';
  if (connection.textContent !== label) connection.textContent = label;
  connection.classList.toggle('offline', !online);
  byId('sync').textContent = lastSync ? 'Last synced · ' + formatTime(lastSync) : 'Awaiting first sync';
  if (byId('health-state')) byId('health-state').textContent = label + '. ' + byId('sync').textContent;
}

function ingest(snapshot) {
  const { serverTime, ...records } = snapshot;
  if (lastSync && serverTime < lastSync) return;
  lastSync = serverTime;
  online = true;
  const fingerprint = JSON.stringify(records);
  if (fingerprint !== stateStamp) {
    state = records;
    stateStamp = fingerprint;
    render();
  } else {
    updateConnection();
  }
}

async function poll() {
  try {
    const response = await fetch('/api/v1/state', { signal: AbortSignal.timeout(4000) });
    if (!response.ok) throw new Error('Could not sync.');
    ingest(await response.json());
  } catch {
    online = false;
    updateConnection();
  } finally {
    setTimeout(poll, 1500);
  }
}

function navigate(next, personal = false) {
  if (byId('message')?.value.trim() && next !== page &&
      !window.confirm('Leave this view with an unsent message?')) return;
  page = next;
  myTasks = personal;
  notice('');
  for (const button of byId('tabs').querySelectorAll('button')) {
    if (button.dataset.page === next) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  }
  const railTarget = ['People', 'System health'].includes(next) || personal ? next : 'Overview';
  for (const button of document.querySelectorAll('.rail button')) {
    button.classList.toggle('rail-active', button.dataset.page === railTarget);
  }
  render();
}

async function submit(kind, details, pendingID) {
  const id = pendingID || tabID + '-' + (++fallbackID);
  try {
    const response = await fetch('/api/v1/state', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind, actor: actor(), id, ...details }),
      signal: AbortSignal.timeout(5000),
    });
    if (!response.ok) throw Object.assign(new Error(await response.text()), { status: response.status });
    ingest(await response.json());
  } catch (error) {
    if (error.status) throw error;
    online = false;
    updateConnection();
    throw new Error('Delivery uncertain. Retry this same draft to avoid a duplicate.');
  }
}

function openEditor(kind, index) {
  draft = { kind, index };
  const row = state.scope[index];
  const checkpointBody = kind === 'checkpoint' ? [
    'CONFIRMED FACTS', 'Encryption was observed on the customer records volume.',
    ...state.scope.map(item => item.name + ' — availability: ' + item.availability + '; recovery: ' + item.recovery + '.'),
    '', 'OPEN ASSESSMENTS',
    ...state.scope.map(item => item.name + ' — ' + item.exposure + '; exfiltration: ' + item.exfiltration + ' · ' + item.evidence + '.'),
    '', 'OUTSTANDING WORK',
    ...state.tasks.filter(task => !task.done).map(task => task.owner + ' — ' + task.title + ' · ' + task.due),
    '', 'PENDING DECISION', 'Maya Chen — approve phased return to service after restore validation and exposure review.',
    '', 'RECENT CHANGES', ...state.events.slice(0, 4).map(event => formatTime(event.time) + ' — ' + event.title),
  ].join('\n') : '';
  if (kind === 'scope') draft.revision = row.revision;
  editor.innerHTML = `<h2 id="editor-title">${kind === 'scope' ? escape(row.name) : 'Review shift checkpoint'}</h2>
    <form class="form" id="edit-form">
    ${kind === 'scope' ? '<div class="fields">' + fields.map(field => `<label>${field[0].toUpperCase() + field.slice(1)}
    <select name="${field}">${statuses[field].map(option => `<option ${option === row[field] ? 'selected' : ''}>${escape(option)}</option>`).join('')}</select></label>`).join('') +
    '</div><p class="small muted">Current rationale · ' + escape(row.reason) + '</p>' : '<p class="small muted">Review and edit the briefing before publication.</p>'}
    <label>${kind === 'scope' ? 'Revision rationale' : 'Handover briefing'}<textarea name="body" maxlength="12000" required>${escape(checkpointBody)}</textarea></label>
    <p id="edit-error" class="error small" role="alert"></p>
    <div class="actions"><button class="button primary" type="submit">${kind === 'scope' ? 'Save assessment' : 'Publish checkpoint'}</button>
    ${action('Cancel', 'cancel')}</div></form>`;
  editor.showModal();
}

function exportRecord() {
  const blob = new Blob([JSON.stringify({ classification: 'Synthetic exercise', exportedAt: new Date().toISOString(), ...state }, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'aegis-IR-2026-017-exercise.json';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  notice('Exercise record downloaded.');
}

byId('tabs').innerHTML = views.map(view => '<button data-page="' + view + '">' + view + '</button>').join('');
document.addEventListener('click', async event => {
  const button = event.target.closest('button');
  if (!button) return;
  const { page: next, action: kind, index } = button.dataset;
  if (next) return navigate(next, next === 'Tasks' && !!button.closest('.rail'));
  if (button.id === 'focus') {
    if (focus && page === 'Overview' && byId('message')?.value.trim() &&
        !window.confirm('Exit Focus view with an unsent message?')) return;
    focus = !focus;
    document.body.classList.toggle('focus-mode', focus);
    button.setAttribute('aria-pressed', focus);
    button.textContent = focus ? 'Exit focus view' : 'Focus view';
    render();
  }
  if (!state || !kind) return;
  if (kind === 'cancel') return editor.close();
  if (kind === 'tasks-view') return navigate('Tasks');
  if (kind === 'review-view') return navigate('Review');
  if (kind === 'export') return exportRecord();
  if (kind === 'scope' || kind === 'checkpoint') return openEditor(kind, Number(index));
  button.disabled = true;
  try {
    await submit(kind, kind === 'handover' ? { checkpointTime: state.checkpoint.time } : { index: Number(index) });
    notice(kind === 'task' ? 'Task marked complete.' : 'Acknowledgment saved.');
  } catch (error) {
    notice(error.message);
  } finally {
    button.disabled = false;
  }
});

let sending = false;
let messageRequest;
document.addEventListener('submit', async event => {
  const form = event.target;
  if (!['compose', 'edit-form'].includes(form.id)) return;
  event.preventDefault();
  const details = Object.fromEntries(new FormData(form));
  const button = form.querySelector('[type="submit"]');
  if (form.id === 'compose') {
    if (sending) return;
    sending = true;
    details.critical = details.critical === 'on';
    const signature = JSON.stringify([actor(), details]);
    if (messageRequest?.signature !== signature) messageRequest = { signature, id: tabID + '-' + (++fallbackID) };
    button.disabled = true;
    byId('send-status').textContent = 'Pending · waiting for server';
    try {
      await submit('message', details, messageRequest.id);
      const current = byId('compose');
      if (current?.elements.body.value === details.body) {
        current.reset();
        byId('send-status').textContent = 'Sent · saved on server';
      }
      messageRequest = undefined;
    } catch (error) {
      if (byId('send-status')) byId('send-status').textContent = error.message;
      else notice(error.message);
    } finally {
      sending = false;
      button.disabled = false;
    }
    return;
  }
  button.disabled = true;
  form.querySelector('[data-action="cancel"]').disabled = true;
  const errorBox = byId('edit-error');
  errorBox.textContent = 'Saving…';
  try {
    const payload = { ...details, index: draft.index, revision: draft.revision };
    const signature = JSON.stringify([actor(), payload]);
    if (draft.signature !== signature) {
      draft.signature = signature;
      draft.requestID = tabID + '-' + (++fallbackID);
    }
    await submit(draft.kind, payload, draft.requestID);
    editor.close();
    render();
    notice('Saved on the local server.');
  } catch (error) {
    errorBox.textContent = error.message;
  } finally {
    button.disabled = false;
    form.querySelector('[data-action="cancel"]').disabled = false;
  }
});

editor.addEventListener('cancel', event => {
  if (editor.querySelector('[type="submit"]')?.disabled) event.preventDefault();
});
byId('actor').addEventListener('change', render);
window.addEventListener('beforeunload', event => {
  if (!byId('message')?.value.trim() && !editor.open) return;
  event.preventDefault();
  event.returnValue = '';
});
navigate('Overview');
poll();
