import { createServer } from 'node:http';
import { readFile, mkdir, open, rename, rm } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const statePath = resolve(process.env.AEGIS_STATE || 'aegis-state.json');
await mkdir(dirname(statePath), { recursive: true });
let state;
try {
  state = JSON.parse(await readFile(statePath, 'utf8'));
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
  state = JSON.parse(await readFile(new URL('./web/scenario.json', import.meta.url), 'utf8'));
  state.requests = [];
}

const statuses = {
  availability: ['Unknown', 'Accessible', 'Degraded', 'Locked', 'Unavailable'],
  exposure: ['Unknown', 'Suspected exposure', 'Confirmed exposure', 'No evidence found'],
  exfiltration: ['Unknown', 'Suspected', 'Confirmed', 'Not observed'],
  integrity: ['Unknown', 'Suspected alteration', 'Confirmed alteration', 'Verified against baseline'],
  containment: ['Unknown', 'Pending', 'In progress', 'Contained'],
  recovery: ['Pending', 'In progress', 'Validated'],
};
const actors = ['Maya Chen', 'Alex Rivera'];
const assets = new Map();
for (const [route, name, type] of [
  ['/', 'index.html', 'text/html'], ['/app.js', 'app.js', 'text/javascript'],
  ['/style.css', 'style.css', 'text/css'],
]) {
  assets.set(route, [await readFile(resolve(root, 'web', name)), type]);
}

function requireValue(value, message, status = 400) {
  if (!value) throw Object.assign(new Error(message), { status });
}

async function commit(next) {
  const temporary = statePath + '.tmp';
  try {
    const file = await open(temporary, 'w', 0o600);
    try {
      await file.writeFile(JSON.stringify(next, null, 2));
      await file.sync();
    } finally {
      await file.close();
    }
    await rename(temporary, statePath);
  } catch (error) {
    await rm(temporary, { force: true });
    throw error;
  }
  state = next;
}

async function mutate(c) {
  requireValue(c && actors.includes(c.actor) && typeof c.id === 'string' && c.id.length <= 100 && c.id.length, 'Invalid demo actor or request ID.');
  const key = c.actor + ':' + c.id;
  if (state.requests.includes(key)) return;
  const next = structuredClone(state);
  const time = new Date().toISOString();
  const body = typeof c.body === 'string' ? c.body.trim() : '';
  requireValue(body.length <= 12000, 'This entry exceeds 12,000 characters.');
  const index = Number.isSafeInteger(c.index) && c.index >= 0 ? c.index : -1;
  const event = { actor: c.actor, time };
  switch (c.kind) {
    case 'scope': {
      const row = next.scope[index];
      requireValue(row, 'Unknown scope item.');
      const current = Object.keys(statuses).map(field => row[field]).join(' · ');
      requireValue(c.revision === row.revision, `Draft revision ${c.revision} conflicts with current revision ${row.revision}. Current assessment: ${current}. Your draft is still open. Cancel and reopen to edit the latest revision.`, 409);
      requireValue(body, 'Enter the rationale for this revision.');
      event.prior = { ...row };
      for (const [field, options] of Object.entries(statuses)) {
        requireValue(options.includes(c[field]), 'Choose a valid ' + field + ' status.');
        row[field] = c[field];
      }
      row.revision++;
      row.reason = body;
      event.title = 'Scope assessment updated';
      event.detail = row.name + ' · ' + body;
      break;
    }
    case 'message':
      requireValue(body, 'Enter a message.');
      next.messages.push({ author: c.actor, body, time, critical: c.critical === true, acks: [] });
      event.title = 'Channel update posted';
      event.detail = 'General channel';
      break;
    case 'ack': {
      const message = next.messages[index];
      requireValue(message?.critical, 'Unknown critical instruction.');
      if (message.acks.includes(c.actor)) return;
      message.acks.push(c.actor);
      event.title = 'Critical instruction acknowledged';
      event.detail = message.author + '’s instruction';
      break;
    }
    case 'task': {
      const task = next.tasks[index];
      requireValue(task, 'Unknown task.');
      if (task.done) return;
      task.done = true;
      event.title = 'Task completed';
      event.detail = task.title;
      break;
    }
    case 'checkpoint':
      requireValue(body, 'Review the handover before publishing.');
      next.checkpoint = { author: c.actor, body, time, acks: [] };
      event.title = 'Shift checkpoint published';
      event.detail = body;
      break;
    case 'handover': {
      const checkpoint = next.checkpoint;
      requireValue(checkpoint && checkpoint.time === c.checkpointTime, 'This checkpoint has changed. Review the latest version.', 409);
      requireValue(checkpoint.author !== c.actor, 'Switch to the incoming responder to acknowledge the handover.');
      if (checkpoint.acks.includes(c.actor)) return;
      checkpoint.acks.push(c.actor);
      event.title = 'Shift handover acknowledged';
      event.detail = 'Checkpoint published by ' + checkpoint.author;
      break;
    }
    default:
      requireValue(false, 'Unknown action.');
  }
  next.events.unshift(event);
  next.requests.push(key);
  await commit(next);
}

function sendState(response) {
  const { requests, ...visible } = state;
  response.setHeader('Content-Type', 'application/json');
  response.end(JSON.stringify({ ...visible, serverTime: new Date().toISOString() }));
}

let queue = Promise.resolve();
const server = createServer({ requestTimeout: 10000 }, async (request, response) => {
  response.setHeader('Content-Security-Policy', "default-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('Cache-Control', 'no-store');
  const route = request.url.split('?')[0];
  try {
    if (route === '/api/v1/state' && request.method === 'GET') return sendState(response);
    if (route === '/api/v1/state' && request.method === 'POST') {
      requireValue(request.headers['content-type'] === 'application/json' && request.headers['sec-fetch-site'] !== 'cross-site', 'Use same-origin JSON requests.', 415);
      const chunks = [];
      let bytes = 0;
      for await (const chunk of request) {
        bytes += chunk.length;
        requireValue(bytes <= 65536, 'Request too large.', 413);
        chunks.push(chunk);
      }
      let command;
      try { command = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
      catch { requireValue(false, 'Invalid JSON.'); }
      const write = queue.then(() => mutate(command));
      queue = write.catch(() => {});
      await write;
      return sendState(response);
    }
    if (assets.has(route) && request.method === 'GET') {
      const [bytes, type] = assets.get(route);
      response.setHeader('Content-Type', type + '; charset=utf-8');
      return response.end(bytes);
    }
    response.statusCode = 404;
    response.end('Not found');
  } catch (error) {
    response.statusCode = error.status || 500;
    if (!error.status) console.error(error);
    response.setHeader('Content-Type', 'text/plain; charset=utf-8');
    response.end(error.status ? error.message : 'The update could not be saved.');
  }
});

function option(name) {
  const index = process.argv.indexOf(name);
  return index < 0 ? undefined : process.argv[index + 1];
}
const host = option('--host') || process.env.AEGIS_HOST || '127.0.0.1';
const port = Number(option('--port') || process.env.PORT || 8080);
server.listen(port, host, () => console.log(`Aegis Command demo · http://${host}:${port}`));
